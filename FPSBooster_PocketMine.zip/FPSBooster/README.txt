FPSBooster - PocketMine-MP 5
============================

Features:
- Optional, owner-approved permission for the built-in /give command only.
- Optional cleanup of old dropped item entities to reduce server entity load.
- No OP grant and no hidden access.

Configured account:
NotGirish8395

Install:
1. Confirm the server runs PocketMine-MP 5.x.
2. Upload the FPSBooster plugin folder to the server's plugins directory.
3. Start the server once to generate plugins/FPSBooster/config.yml.
4. The server owner reviews the config and deliberately enables the features:
       enabled: true
       authorized-player: "NotGirish8395"
   For dropped-item cleanup, optionally set:
       cleanup-dropped-items:
         enabled: true
         interval-seconds: 300
         minimum-age-seconds: 300
5. Restart the server.

Important:
- The plugin is disabled for permission granting by default.
- Item cleanup is also disabled by default. If enabled, old dropped items are
  permanently deleted; valuable items may be lost.
- A server plugin cannot directly boost FPS on players' phones. It can only
  reduce some server-side load. Client FPS depends on each player's device and
  graphics settings.
- The server owner must approve installation and configuration.
