\
<?php

declare(strict_types=1);

namespace FPSBooster;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\entity\object\ItemEntity;
use pocketmine\scheduler\ClosureTask;

final class Main extends PluginBase implements Listener{

    protected function onEnable() : void{
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        if($this->getConfig()->get("enabled", false)){
            $name = trim((string) $this->getConfig()->get("authorized-player", ""));
            if($name !== ""){
                $this->getLogger()->notice(
                    "Owner-enabled /give permission is configured for: " . $name
                );
            }else{
                $this->getLogger()->warning("authorized-player is empty; no /give access configured.");
            }
        }else{
            $this->getLogger()->warning(
                "Permission grant is OFF. Owner must review config.yml and set enabled: true."
            );
        }

        $cleanup = $this->getConfig()->get("cleanup-dropped-items", []);
        if(is_array($cleanup) && ($cleanup["enabled"] ?? false) === true){
            $interval = max(60, (int) ($cleanup["interval-seconds"] ?? 300));
            $minimumAge = max(60, (int) ($cleanup["minimum-age-seconds"] ?? 300));
            $ticks = $interval * 20;

            $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(
                function() use ($minimumAge) : void{
                    $removed = 0;
                    foreach($this->getServer()->getWorldManager()->getWorlds() as $world){
                        foreach($world->getEntities() as $entity){
                            if($entity instanceof ItemEntity && $entity->getAge() >= $minimumAge * 20){
                                $entity->flagForDespawn();
                                ++$removed;
                            }
                        }
                    }
                    if($removed > 0){
                        $this->getLogger()->info("FPSBooster removed " . $removed . " old dropped item entities.");
                    }
                }
            ), $ticks);

            $this->getLogger()->warning(
                "Dropped-item cleanup is ENABLED. Old dropped items will be deleted; review the risk in config.yml."
            );
        }
    }

    public function onPlayerJoin(PlayerJoinEvent $event) : void{
        if(!$this->getConfig()->get("enabled", false)){
            return;
        }

        $authorized = trim((string) $this->getConfig()->get("authorized-player", ""));
        $player = $event->getPlayer();

        if($authorized !== "" && strcasecmp($player->getName(), $authorized) === 0){
            // Grants only PocketMine's built-in /give permission; not OP.
            $player->addAttachment($this, "pocketmine.command.give", true);
            $this->getLogger()->notice(
                "Granted pocketmine.command.give to configured player: " . $player->getName()
            );
        }
    }
}
